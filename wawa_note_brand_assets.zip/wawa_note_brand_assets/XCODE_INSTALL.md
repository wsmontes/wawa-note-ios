# Installing wawa-note App Icon in Xcode

1. Open the project in Xcode.
2. In Finder, open this asset package.
3. Copy `AppIcon.appiconset`.
4. Paste it into:

```text
wawa-note/Resources/Assets.xcassets/
```

5. If Xcode asks to replace the existing AppIcon set, choose Replace.
6. Build and run on simulator or iPhone.

Optional:
- Keep `AppIcon-Dark.appiconset` as an alternative, but do not enable both at the same time unless you configure alternate app icons later.
