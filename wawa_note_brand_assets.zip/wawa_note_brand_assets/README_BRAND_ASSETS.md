# wawa-note Brand Assets

Generated asset package for the iOS app.

## Recommended usage

### Primary app icon
Use:

```text
AppIcon.appiconset
```

Copy this folder into:

```text
wawa-note/Resources/Assets.xcassets/
```

Then select `AppIcon` as the app icon set in Xcode if needed.

### Main logo / wordmark
Use:

```text
Wordmark-Horizontal-Light-Transparent.png
Wordmark-Horizontal-Dark-Transparent.png
Wordmark-Horizontal.svg
```

### Symbol-only logo
Use:

```text
Symbol-Gradient-Transparent-1024.png
Symbol-White-Transparent-1024.png
Symbol-Dark-Transparent-1024.png
Symbol-Gradient.svg
Symbol-Dark.svg
```

### Splash / welcome screen
Use:

```text
Splash-iPhone14Plus-Dark.png
```

## Color direction

Primary gradient:

```text
Cyan   #0CB5FF
Blue   #196EF0
Purple #7352FF
```

Dark text/background:

```text
Ink       #141C2A
Deep navy #050A18
```

## Product fit

The mark uses a rounded waveform-like W:

- `W` for wawa
- waveform/audio for recording/transcription
- soft dot for AI assistant presence
- rounded geometry for native iOS friendliness

## Notes

- App icon PNG files are square and opaque, as expected for iOS app icons.
- Transparent PNGs are intended for in-app UI, splash screens, documents, and marketing.
- SVG files are useful for future refinement or web/marketing usage.
